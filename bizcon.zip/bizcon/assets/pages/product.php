<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Product Page</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    header {
        background-color: #333;
        color: white;
        padding: 20px;
        text-align: center;
    }

    button {
        background-color: #4CAF50;
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin-bottom: 20px;
        cursor: pointer;
        border-radius: 4px;
    }

    button:hover {
        background-color: #45a049;
    }

    .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 20px;
        padding: 20px;
    }

    .product {
        background-color: #f4f4f4;
        border: 1px solid #ddd;
        padding: 20px;
        text-align: center;
    }

    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
</style>
</head>
<body>

<header>
    <h1>Product Page</h1>
    <button id="addProductBtn">Add Product</button>
</header>

<main>
    <div class="product-grid">
        <!-- Product items will be dynamically added here -->
    </div>
</main>

<!-- Modal for adding a new product -->
<div id="addProductModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Add Product</h2>
        <form id="addProductForm">
            <label for="productName">Product Name:</label>
            <input type="text" id="productName" name="productName" required>
            <label for="productPrice">Product Price:</label>
            <input type="number" id="productPrice" name="productPrice" min="0" step="0.01" required>
            <button type="submit">Add</button>
        </form>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const addProductBtn = document.getElementById("addProductBtn");
        const addProductModal = document.getElementById("addProductModal");
        const closeBtn = document.querySelector(".close");
        const addProductForm = document.getElementById("addProductForm");
        const productGrid = document.getElementById("productGrid");

        // Function to open the modal
        addProductBtn.addEventListener("click", function () {
            addProductModal.style.display = "block";
        });

        // Function to close the modal
        closeBtn.addEventListener("click", function () {
            addProductModal.style.display = "none";
        });

        // Function to handle file input change and preview image
        document.getElementById("productImage").addEventListener("change", function (event) {
            const file = event.target.files[0];
            const reader = new FileReader();

            reader.onload = function (e) {
                document.getElementById("previewImage").src = e.target.result;
                document.getElementById("previewImage").style.display = "block";
            };

            reader.readAsDataURL(file);
        });

        // Function to add a new product
        addProductForm.addEventListener("submit", function (e) {
            e.preventDefault();
            const productName = document.getElementById("productName").value;
            const productPrice = document.getElementById("productPrice").value;
            const productImage = document.getElementById("productImage").files[0];
            const productImageUrl = document.getElementById("previewImage").src;

            // Create a new product item
            const productItem = document.createElement("div");
            productItem.classList.add("product");
            productItem.innerHTML = `
                <h3>${productName}</h3>
                <img src="${productImageUrl}" alt="${productName}">
                <p>$${productPrice}</p>
                <button class="removeBtn">Remove</button>
            `;

            // Add event listener to remove button
            const removeBtn = productItem.querySelector(".removeBtn");
            removeBtn.addEventListener("click", function () {
                productGrid.removeChild(productItem);
            });

            // Append the new product item to the grid
            productGrid.appendChild(productItem);

            // Close the modal
            addProductModal.style.display = "none";
            addProductForm.reset();
            document.getElementById("previewImage").style.display = "none";
        });
    });
</script>
</body>
</html>






