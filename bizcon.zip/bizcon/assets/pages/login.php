<div class="login">
    <div class="col-sm-12 col-md-4 bg-light-purple border rounded p-4 shadow-sm">
        <form method="post" action="assets/php/actions.php?login">
            <div class="d-flex justify-content-center mb-4">
                <img src="assets/images/bizcon.png" alt="" height="45">
            </div>
            <h1 class="h5 mb-3 fw-normal text-center">Log In</h1>

            <div class="form-floating mb-3">
                <input type="text" name="username_email" value="<?=showFormData('username_email')?>" class="form-control rounded-0" placeholder="username/email">
                <label for="floatingInput">Username</label>
            </div>
            <?=showError('username_email')?>
            <div class="form-floating mb-3">
                <input type="password" name="password" class="form-control rounded-0" id="floatingPassword" placeholder="Password">
                <label for="floatingPassword">********</label>
            </div>
            <?=showError('password')?>
            <?=showError('checkuser')?>

            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="?forgotpassword&newfp" class="text-decoration-none">Forgot password?</a>
                <a href="?signup" class="text-decoration-none">Create New Account</a>
            </div>
            <div class="d-grid">
                <button class="btn btn-primary btn-lg" type="submit">Sign in</button>
            </div>
        </form>
    </div>
</div>

<style>
    .bg-light-purple {
        background-color: #E6E6FA;
    }
</style>
