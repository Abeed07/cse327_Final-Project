-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2024 at 08:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bizcon`
--

-- --------------------------------------------------------

--
-- Table structure for table `block_list`
--

CREATE TABLE `block_list` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `blocked_user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `comment`, `created_at`) VALUES
(50, 33, 21, 'Any discount?', '2024-05-22 18:19:33');

-- --------------------------------------------------------

--
-- Table structure for table `follow_list`
--

CREATE TABLE `follow_list` (
  `id` int(11) NOT NULL,
  `follower_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `follow_list`
--

INSERT INTO `follow_list` (`id`, `follower_id`, `user_id`) VALUES
(13, 9, 3),
(15, 9, 6),
(38, 10, 3),
(42, 10, 7),
(43, 10, 9),
(57, 8, 4),
(58, 8, 5),
(66, 10, 11),
(68, 11, 10),
(69, 11, 7),
(70, 11, 9),
(71, 11, 3),
(76, 14, 3),
(77, 14, 7),
(78, 14, 4),
(79, 14, 8),
(80, 15, 7),
(81, 15, 6),
(82, 15, 8),
(83, 15, 5),
(84, 15, 4),
(85, 15, 3),
(86, 15, 18),
(87, 15, 16),
(88, 15, 19),
(89, 15, 17),
(90, 17, 15),
(91, 17, 16),
(92, 17, 18),
(93, 17, 19),
(94, 18, 15),
(95, 18, 16),
(96, 18, 17),
(97, 18, 19),
(98, 19, 15),
(99, 19, 16),
(100, 19, 17),
(101, 19, 18),
(102, 20, 17),
(103, 20, 16),
(104, 20, 15),
(105, 21, 20),
(106, 21, 19),
(107, 21, 18),
(108, 21, 17);

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `post_id`, `user_id`) VALUES
(92, 32, 21),
(93, 31, 21),
(94, 33, 21),
(95, 30, 21),
(97, 28, 21);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `msg` text NOT NULL,
  `read_status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `from_user_id` int(11) NOT NULL,
  `read_status` int(11) NOT NULL DEFAULT 0,
  `post_id` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `to_user_id`, `message`, `created_at`, `from_user_id`, `read_status`, `post_id`) VALUES
(130, 20, 'started following you !', '2024-05-22 18:17:38', 21, 0, '0'),
(131, 19, 'started following you !', '2024-05-22 18:17:43', 21, 0, '0'),
(132, 18, 'started following you !', '2024-05-22 18:17:44', 21, 0, '0'),
(133, 17, 'started following you !', '2024-05-22 18:17:45', 21, 0, '0'),
(134, 19, 'liked your post !', '2024-05-22 18:17:55', 21, 0, '32'),
(135, 19, 'liked your post !', '2024-05-22 18:17:57', 21, 0, '31'),
(136, 19, 'commented on your post', '2024-05-22 18:18:08', 21, 0, '31'),
(137, 19, 'commented on your post', '2024-05-22 18:18:13', 21, 0, '31'),
(138, 19, 'liked your post !', '2024-05-22 18:19:24', 21, 0, '33'),
(139, 19, 'commented on your post', '2024-05-22 18:19:33', 21, 0, '33'),
(140, 19, 'liked your post !', '2024-05-22 18:19:49', 21, 0, '30'),
(141, 18, 'liked your post !', '2024-05-22 18:19:53', 21, 0, '29'),
(142, 18, 'unliked your post !', '2024-05-22 18:19:54', 21, 0, '29'),
(143, 18, 'liked your post !', '2024-05-22 18:19:56', 21, 0, '28');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_img` text NOT NULL,
  `post_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `post_img`, `post_text`, `created_at`) VALUES
(14, 15, '17163989971shoe.jpeg', 'VIR shoes\r\nTk. 2499', '2024-05-22 17:29:57'),
(15, 15, '1716399041shoe2.jpeg', 'Kid\'s shoes\r\nTk. 1099', '2024-05-22 17:30:41'),
(16, 15, '1716399082watch2.png', 'Cool watch \r\nTk.1699', '2024-05-22 17:31:22'),
(17, 15, '1716399103pant1.jpeg', 'Casual Pant\r\nTk. 599', '2024-05-22 17:31:43'),
(18, 16, '1716399335aq.jpeg', 'Aquarium\r\nTk.1299', '2024-05-22 17:35:35'),
(19, 16, '1716399361soga.jpeg', '5 month used\r\nTk.12000', '2024-05-22 17:36:01'),
(20, 16, '1716399404bed.jpeg', '2 year used. like new\r\nTk. 18000 (fixed)', '2024-05-22 17:36:44'),
(21, 16, '1716399445cum.jpeg', 'sofa bed\r\nTk.25000', '2024-05-22 17:37:25'),
(22, 17, '1716399695ehgfh.jpg', 'Special Offer\r\nTk.90000', '2024-05-22 17:41:35'),
(23, 17, '1716399731dgh.jpg', 'Very Cool AC\r\ndelivered in a year\r\nTk. 70000', '2024-05-22 17:42:11'),
(24, 17, '1716399758dghgwrth.jpg', 'Dinner set\r\nTk. 899', '2024-05-22 17:42:38'),
(25, 17, '1716399796bik.png', 'Yamaha R15\r\nTk. 500000', '2024-05-22 17:43:16'),
(26, 18, '1716400092dfh.jpeg', 'Alu\r\nTk 30/kg', '2024-05-22 17:48:12'),
(27, 18, '1716400151sreth.jpeg', 'Coke\r\nTk.25', '2024-05-22 17:49:11'),
(28, 18, '1716400169xfbn.jpeg', 'Brinjal\r\nTk.50', '2024-05-22 17:49:29'),
(29, 18, '1716400186fgnz.jpeg', 'Onion\r\nTk.30/kg', '2024-05-22 17:49:46'),
(30, 19, '1716400439zfdhg.jpg', 'Suit\r\nTk.10000', '2024-05-22 17:53:59'),
(31, 19, '1716400503SCV.jpg', 'Dress\r\nTk.1299', '2024-05-22 17:55:03'),
(32, 19, '1716400528zdbzb.jpeg', 'Dress\r\nTk.2999', '2024-05-22 17:55:28'),
(33, 19, '1716400546SFg.jpg', 'Shirt\r\nTk.700', '2024-05-22 17:55:46');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Name` varchar(255) NOT NULL,
  `Price` int(255) NOT NULL,
  `imglink` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `profile_pic` text NOT NULL DEFAULT 'default_profile.jpg',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ac_status` int(11) NOT NULL COMMENT '0=not verified,1=active,2=blocked'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `email`, `username`, `password`, `profile_pic`, `created_at`, `updated_at`, `ac_status`) VALUES
(15, 'Daraz', 'BD', 0, 'daraz@gmail.com', 'Daz', '90ad6b3efcd7f2886df7e74fada77521', '1716398803Daraz_2022_stacked.png', '2024-05-22 17:20:25', '2024-05-22 17:26:43', 1),
(16, 'bikroy', 'bd', 0, 'bikroy@gmail.com', 'bkroy', '238b7a263052be88c3819b6026971d9b', '1716399219bk.png', '2024-05-22 17:21:20', '2024-05-22 17:33:39', 1),
(17, 'evaly', 'bd', 0, 'evaly@gmail.com', 'Evaly', '8cd65e664163b84672dfadd4ab7f3fb1', '1716399542evaly.jpg', '2024-05-22 17:21:54', '2024-05-22 17:39:02', 1),
(18, 'chal', 'dal', 0, 'chaldal@gmail.com', 'chaldal', '10026442a2b4531a1c7476190854b28a', '1716399974xb.jpeg', '2024-05-22 17:22:28', '2024-05-22 17:46:14', 1),
(19, 'infinity', 'jamuna', 0, 'infinity@gmail.com', 'infinity', 'f2fdee93271556e428dd9507b3da7235', '1716400339Infinity-social-Logo.png', '2024-05-22 17:23:04', '2024-05-22 17:52:19', 1),
(20, 'Abeed', 'Pasha', 0, 'abeed07xd@gmail.com', 'Abeed', 'e2d1b808bccade279945759c09f5b7aa', '1716401615me.jpg', '2024-05-22 17:59:39', '2024-05-22 18:13:35', 1),
(21, 'Sirajus', 'Salekin', 2, 'Sirajus@gmail.com', 'Salekin', '1357bd6a0267108e77443b3cf9b2cdc1', '1716401793431671335_3528428334136400_736233001345222043_n.jpg', '2024-05-22 18:00:11', '2024-05-22 18:16:33', 1);

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `before_insert_users` BEFORE INSERT ON `users` FOR EACH ROW BEGIN
    SET NEW.ac_status = 1;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `block_list`
--
ALTER TABLE `block_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `follow_list`
--
ALTER TABLE `follow_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `block_list`
--
ALTER TABLE `block_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `follow_list`
--
ALTER TABLE `follow_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
